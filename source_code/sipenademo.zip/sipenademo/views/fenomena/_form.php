<?php
/* Daftar modul Yii yang digunakan */

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* Modul-modul yang diperlukan untuk modifikasi kodingan */
use yii\helpers\ArrayHelper;
use app\models\Satker;
use app\models\Bulan;

/* @var $this yii\web\View */
/* @var $model app\models\Fenomena */
/* @var $form yii\widgets\ActiveForm */
?>
<style>
    /*Modifikasi sedikit pada CSS agar tampilan margin pada div dengan class row lebih bagus*/
    .row {
        margin-right: 0px!important;
        margin-left: 0px!important;
    }
    hr {
        margin-top: 0.25px!important;
    }
</style>

<?php
/* Fungsi Javascript untuk memilih petunjuk tambahan yang akan ditampilkan berdasarkan jenis sumber (atribut sumber) yang dipilih. */
/* Jika sumber yang dipilih adalah 0, maka div dengan id=cetak akan ditampilkan, div lainnya disembunyikan */
/* Jika sumber yang dipilih adalah 1, maka div dengan id=online akan ditampilkan, div lainnya disembunyikan */
/* Jika sumber yang dipilih adalah 2, maka div dengan id=narasumber akan ditampilkan, div lainnya disembunyikan */
$script = <<< JS

$(document).ready(function () {
    $(document.body).on('change', '#fenomena-sumber', function () {
        var val = $('#fenomena-sumber').val();
        if(val == 0 ) {
            $('#cetak').show();
            $('#online').hide();
            $('#narasumber').hide();
        }
        else if(val == 1){
            $('#cetak').hide();
            $('#online').show();
            $('#narasumber').hide();
        }
        else if(val == 2){
            $('#cetak').hide();
            $('#online').hide();
            $('#narasumber').show();
        }
    });
});
        
JS;
$this->registerJs($script);
?>

<script type="text/javascript">
$(document).ready(function () {
    $('#checkBtn').click(function() {
		/*Mengecek apakah checkbox sudah ada yang dipilih saat tombol simpan (dengan id#checkBtn) dipilih.*/
		checked = $("input[type=checkbox]:checked").length;

		if(!checked) {
			/*Jika belum ada yang dipilih, akan muncul popup error berikut*/
			alert("Pilih minimal salah satu keterkaitan fenomena.");
			return false;
		}

    });
});

</script>

<div class="fenomena-form">
    <?php $form = ActiveForm::begin(); ?>
    <div class="alert alert-success">
        <!--Segmen 1-->
        <div class="row">
            <div class="row">
                <h3>
                    <b>Data-data Fenomena</b>
                </h3>
                <div class="col-md-6">
                    <!--Isian wilayah-->
                    <!--Dropdownlist yang tampil untuk orang provinsi dapat dipilih-->
                    <?php if (Yii::$app->user->identity->id_satker == 1700)://jika org prov  ?>
                        <?=
                                $form->field($model, 'wilayah')//isian atribut wilayah
                                ->dropDownList(//berupa dropdownlist dari model Satker
                                        ArrayHelper::map(Satker::find()->all(), 'id_satker', 'dropdownsatker'), [
                                    'prompt' => 'Pilih Wilayah ...', //prompt (nama dropdown)
                                    /* menentukan apakah pilihan bisa dipilih (true or false) dari fungsi getLokasi() di model Fenomena.php */
                                    'disabled' => $model->getLokasi()
                                        ]
                                )
                        ?> 
                        <!--Dropdownlist yang tampil untuk orang kabupaten tidak dapat dipilih (selected)-->
                    <?php else: //jika orang kabupaten?>
                        <?=
                                $form->field($model, 'wilayah')
                                ->dropDownList(
                                        ArrayHelper::map(Satker::find()->all(), 'id_satker', 'dropdownsatker'), [
                                    'prompt' => 'Pilih Wilayah ...',
                                    'options' => [(Yii::$app->user->identity->id_satker) => array('selected' => 'selected')],
                                    'disabled' => $model->getLokasi()
                                        ]
                                )
                        ?>  
                    <?php endif; ?>
                </div>
                <div class="col-md-6" style="line-height: 2em;">
                    <!--Petunjuk isian fenomena-->
                    <i>
                        Wilayah tempat terjadinya fenomena. Wilayah yang dapat Anda catat adalah wilayah satuan kerja Anda.
                    </i>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <!--Isian tahun-->
                    <?= $form->field($model, 'tahun')->dropDownList($model->getYears(), ['prompt' => 'Pilih Tahun ...']); ?>
                </div>
                <div class="col-md-6" style="line-height: 2em;">
                    <!--Petunjuk isian tahun-->
                    <hr/>
                    <i>
                        Tahun terjadinya fenomena. Tahun yang dapat dientri adalah sejak 2010 hingga tahun ini.
                    </i>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <!--Isian bulan-->
                    <?=
                            $form->field($model, 'bulan')
                            ->dropDownList(
                                    ArrayHelper::map(Bulan::find()->all(), 'id_bulan', 'nama_bulan'), ['prompt' => 'Pilih Bulan ...']
                            )
                    ?> 
                </div>
                <div class="col-md-6" style="line-height: 2em;">
                    <!--Petunjuk isian bulan-->
                    <hr/>
                    <i>
                        Bulan terjadinya fenomena. Biasanya adalah berupa bulan saat diturunkan suatu berita di media.
                    </i>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <!--Isian fenomena-->
                    <?= $form->field($model, 'fenomena')->textarea(['rows' => 6])//ketinggian text area 6 baris ?>
                </div>
                <div class="col-md-6">
                    <!--Petunjuk isian fenomena-->
                    <hr/>
                    <i>
                        Fenomena yang dicatat adalah fenomena yang diberitakan di media cetak ataupun online. Tuliskan RINGKASAN fenomena dalam 1-3 paragraf. Usahakan memuat kaidah 5W dan 1H.
                    </i>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <!--Isian sumber-->
                    <!--Dropdown ini men-trigger fungsi Javascript di atas untuk menampilkan salah satu div petunjuk tambahan di bawah-->
                    <?= $form->field($model, 'sumber')->dropDownList([0 => 'Media Cetak', 1 => 'Media Online', 2 => 'Narasumber'], ['prompt' => 'Pilih Sumber ...'], ['onchange' => 'javascript:$("#mydiv").toggle()',]); ?>
                </div>
                <div class="col-md-6">
                    <!--Petunjuk isian sumber-->
                    <hr/>
                    <i>
                        Sumber yang dipilih dapat berupa media cetak (koran, majalah) dan online (website media massa yang dapat dipercaya).
                    </i>
                </div>
            </div>
            <div class="row">
                <!--Petunjuk isian sumberket (yang tergantung ada isian jenis sumber)-->
                <!--Salah satu div dengan id=cetak, id=online, id=narasumber akan ditampilkan berdasarkan dropdownlist sumber yang dipilih-->
                <div id="cetak" style="display:none" class="alert alert-danger alert-dismissable">
                    <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                    <i class="icon fa fa-check"></i>Tuliskan tanggal dan judul berita.
                </div> 
                <div id="online" style="display:none" class="alert alert-danger alert-dismissable">
                    <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                    <i class="icon fa fa-check"></i>Copy dan paste URL media online tersebut.
                </div>
                <div id="narasumber" style="display:none" class="alert alert-danger alert-dismissable">
                    <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
                    <i class="icon fa fa-check"></i>Tuliskan nama lengkap narasumber.
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <!--Isian sumberket (keterangan sumber)-->
                    <?= $form->field($model, 'sumberket')->textarea(['rows' => 3]) ?>
                </div>
                <div class="col-md-6">
                    <!--Petunjuk isian keterangan sumber-->
                    <hr/>
                    <i>
                        Tuliskan tanggal, nama media cetak, dan judul berita jika fenomena bersumber dari media cetak. 
                        Copy dan paste URL website online jika fenomena bersumber dari media online.
                        Tuliskan nama lengkap narasumber jika fenomena bersumber dari seorang narasumber.
                    </i>
                </div>
            </div>
        </div>
        <hr/>
        <!--Segmen 2-->
        <div class="row">
            <div class="alert alert-warning">
                <h3>
                    <b>Kategori Fenomena Berdasarkan Lapangan Usaha</b>
                </h3>
                <!--Petunjuk isian segmen Lapangan Usaha-->
                <i>
                    Pilih kategori lapangan usaha yang terkait dengan fenomena ini, terutama yang berdampak langsung. <br/>
                    Satu fenomena dapat mempunyai dampak terhadap satu kategori, atau beberapa kategori.
                </i>
                <hr style="border:0"/>
                <div class="row">
                    <div class="col-md-6">
                        <!--Isian kat01 s.d. kat09-->
                        <?= $form->field($model, 'kat01')->checkbox(); ?>
                        <?= $form->field($model, 'kat02')->checkbox(); ?>
                        <?= $form->field($model, 'kat03')->checkbox(); ?>
                        <?= $form->field($model, 'kat04')->checkbox(); ?>
                        <?= $form->field($model, 'kat05')->checkbox(); ?>
                        <?= $form->field($model, 'kat06')->checkbox(); ?>
                        <?= $form->field($model, 'kat07')->checkbox(); ?>
                        <?= $form->field($model, 'kat08')->checkbox(); ?>
                        <?= $form->field($model, 'kat09')->checkbox(); ?>
                    </div>
                    <div class="col-md-6">
                        <!--Isian kat10 s.d. kat17-->
                        <?= $form->field($model, 'kat10')->checkbox(); ?>
                        <?= $form->field($model, 'kat11')->checkbox(); ?>
                        <?= $form->field($model, 'kat12')->checkbox(); ?>
                        <?= $form->field($model, 'kat13')->checkbox(); ?>
                        <?= $form->field($model, 'kat14')->checkbox(); ?>
                        <?= $form->field($model, 'kat15')->checkbox(); ?>
                        <?= $form->field($model, 'kat16')->checkbox(); ?>
                        <?= $form->field($model, 'kat17')->checkbox(); ?>
                    </div>
                </div>
            </div>
        </div>
        <!--Segmen 3-->
        <div class="row">
            <div class="alert alert-warning">
                <h3>
                    <b>Kategori Fenomena Berdasarkan Komponen PDRB Pengeluaran</b>
                </h3>
                <!--Petunjuk isian segmen PDRB Pengeluaran-->
                <i>
                    Pilih komponen PDRB pengeluaran yang terkait dengan fenomena ini, terutama yang berdampak langsung. <br/>
                    Satu fenomena dapat mempunyai dampak terhadap satu komponen, atau beberapa komponen.
                </i>
                <hr style="border:0"/>
                <div class="row">
                    <div class="col-md-6">
                        <!--Isian komp01 s.d. komp04-->
                        <?= $form->field($model, 'komp01')->checkbox(); ?>
                        <?= $form->field($model, 'komp02')->checkbox(); ?>
                        <?= $form->field($model, 'komp03')->checkbox(); ?>
                        <?= $form->field($model, 'komp04')->checkbox(); ?>
                    </div>
                    <div class="col-md-6">
                        <!--Isian komp05 s.d. komp07-->
                        <?= $form->field($model, 'komp05')->checkbox(); ?>
                        <?= $form->field($model, 'komp06')->checkbox(); ?>
                        <?= $form->field($model, 'komp07')->checkbox(); ?>
                    </div>
                </div>
            </div>
        </div>
        <hr/>
        <div class="row">
            <div class="form-group pull-right">
                <?= Html::submitButton('Simpan', ['class' => 'btn btn-success', 'id' => 'checkBtn']) ?>
            </div>
        </div>
    </div>
    <?php ActiveForm::end(); ?>
</div>
