<?php
/*Menggunakan modul Yii*/
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Fenomena */

/*Membuat judul halaman*/
$this->title = 'Rekam Fenomena';
/*Membuat breadcrumbs*/
$this->params['breadcrumbs'][] = ['label' => 'Daftar Fenomena', 'url' => ['index']];
/*Menambahkan variabel title pada parameter breadcrumbs*/
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="fenomena-create">
	<!--Menampilkan judul-->
    <h1><?= Html::encode($this->title) ?></h1>
	<!--Me-render view dari file sipena\views\fenomena\_form.php yang mengandung form isian data fenomena-->
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
