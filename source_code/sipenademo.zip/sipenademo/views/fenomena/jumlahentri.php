<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\ArrayHelper;
use app\models\Satker;
use app\models\Bulan;
use yii\widgets\ActiveForm;

/* Membuat judul halaman dan breadcrumbs */
$this->title = 'Jumlah Entri Fenomena';
$this->params['breadcrumbs'][] = $this->title;
?>

<!--Mengatur style untuk tampilan tabel-->
<style>
    /*Mengatur warna tabel dengan pola warna stripe*/
    .table-striped > tbody > tr:nth-of-type(odd) {
        background-color: #DFF0D8!important;
    }
    .table-striped > thead > tr > th{
        color: #008000!important;
    }
    .table-striped > thead > tr > th > a{
        color: #008000!important;
    }
    .table-striped > tbody > tr > td > a {
        color: #008000!important;
    }
    .row {
        margin-right: 0px!important;
        margin-left: 0px!important;
    }
    .col-md-2, .col-md-3, .col-md-1,.col-md-6 {
        padding-left: 0px!important;
    }
    /*Mengatur lebar tabel agar auto (tidak 100%)*/
    table{
        width: auto!important;
    }
</style>
<div class="fenomena-index">
    <!--Menampilkan judul halaman-->
    <h1>
        <?= Html::encode($this->title) ?>
    </h1>
    <!--Menampilkan keterangan tabel yang ditampilkan-->
    <div class="row">
        <div class="col-md-6">
            <table class="table table-hover" style="width: 50%!important;">
                <tr>
                    <!--Menampilkan parameter tahun dari controller (nilai default tahun ini (2018))-->
                    <th>Tahun</th>
                    <td>
                        <?php echo $tah; ?>
                    </td>
                </tr>
                <tr>
                    <!--Menampilkan parameter tahun dari controller (nilai default bulan ini)-->
                    <th>Bulan</th>
                    <td>
                        <?php echo $bul ?>
                    </td>
                </tr>
            </table>
        </div>
    </div>
	<!--Menampilkan form berbentuk dropdown agar pengguna dapat memilih tahun dan bulan entri fenomena-->
    <div class="row">
        <?php
		/*Inisiasi form isian dropdown*/
        $form = ActiveForm::begin([
					/*Action yang di-trigger oleh form ini adalah actionJumlahentri*/
                    'action' => ['jumlahentri'],
					/*Method yang digunakan adalah GET*/
                    'method' => 'get',
        ]);
        ?>
        <div class="row">
            <div class="col-md-2">
				<!--Dropdown untuk memilih tahun dengan menampilkan daftar tahun dari fungsi getYears() pada model Fenomena.php-->
                <?=
                $form->field($searchModel, 'tahunentri')->dropDownList(
						/*Nilai yang dipilih dimasukkan ke dalam parameter (name) $a*/
                        $searchModel->getYears(), ['class' => 'form-control input', 'prompt' => 'Tahun', 'name' => 'a', 'options' => [$tah => ['Selected' => 'selected']]]
                )->label(false);
                ?>
            </div>
            <div class="col-md-2">
				<!--Dropdown untuk memilih bulan dengan menampilkan daftar bulan dari relation dengan model Bulan.php-->
                <?=
                $form->field($searchModel, 'bulanentri')->dropDownList(
						/*Nilai yang dipilih dimasukkan ke dalam parameter (name) $b*/
                        ArrayHelper::map(Bulan::find()->all(), 'id_bulan', 'nama_bulan'), ['class' => 'form-control input', 'prompt' => 'Bulan', 'name' => 'b', 'options' => [$b => ['Selected' => 'selected']]]
                )->label(false);
                ?>
            </div>
            <div class="col-md-1">
				<!--Button untuk men-trigger action dengan mengirimkan data $a (tahun) dan $b (bulan) dari dropdown di atas-->
                <?= Html::submitButton('Cari ', ['class' => 'btn btn-danger']) ?>
            </div>
        </div>
        <?php ActiveForm::end(); ?>
    </div>
	
	<!--Menampilkan gridview berupa tabel rincian jumlah entri fenomena-->
    <?php
	/*Kolom yang ditampilkan: asal (satker), nama perekam dan jumlah fenomena. Nilai-nilai ini diambil dari query SQL yang ditulis di model CariFenomenaJumlahEntri.php, tepatnya pada fungsi search()*/
    $kolomTampil = [
        ['class' => 'yii\grid\SerialColumn'],
        'asal',
        [
            'attribute' => 'perekam',           
        ],
        [
            'attribute' => 'jum',
            'value' => $searchModel->jum,
        ],
    ];
    ?>
    <?=
    GridView::widget([
        'dataProvider' => $dataProvider,
        'columns' => $kolomTampil,
        'layout' => '<span style = "text-align:left">{summary}</span>{items}{pager} ',
    ]);
    ?>

</div>