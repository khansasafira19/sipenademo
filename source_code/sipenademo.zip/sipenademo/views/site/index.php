<?php
/* Men-daftar modul Yii dalam file ini */

use yii\helpers\Html;
use yii\grid\GridView;
/* Menggunakan model-model yang digunakan dalam relation */
use app\models\Bulan;
use app\models\Satker;
use app\models\Penggunasipantas;
/* Menggunakan modul ArrayHelper */
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $searchModel app\models\CariFenomena */
/* @var $dataProvider yii\data\ActiveDataProvider */

/* Memberi judul pada halaman ini */
$this->title = 'Daftar Fenomena Tahun ' . date("Y");
/* Menampilkan breadcrumbs (navigasi) dengan title */
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="jumbotron" style="background-color: #DFF0D8!important; padding:10px!important">
    <h1>SIPENA</h1>
    <p class="lead">Sistem Perekaman Fenomena</p>
</div>
<div class="fenomena-index">
    <!--Menampilkan title halaman-->
    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]);  ?>

    <p>
        <!--Menampilkan tombol "Rekam Fenomena" di bawah halaman title-->
        <?= Html::a('Rekam Fenomena', ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <!--Menampilkan gridview-->
    <?=
    GridView::widget([
        /* Mengambil dataProvider dan searchModel yang disediakan oleh controller pada fungsi render */
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        /* Memilih kolom/atribut tabel untuk ditampilkan */
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
            //'id',
            'tahun',
            /* Menampilkan atribut bulan menurut nama bulan dari tabel bulan */
            [
                'attribute' => 'month', //nama atribut (relation-nya)
                'value' => 'month.nama_bulan', //nilainya diambil dari fungsi relation
                /* filter-nya berbentuk dropdown list */
                'filter' => Html::activeDropDownList($searchModel, 'month', ArrayHelper::map(Bulan::find()->asArray()->all(), 'nama_bulan', 'nama_bulan'), ['class' => 'form-control input', 'prompt' => 'Pilih Bulan']),
            ],
            /* Menampilkan atribut wilayah menurut nama wilayah dari tabel satker */
            [
                'attribute' => 'satker', //nama relation-nya
                'value' => 'satker.nama_satker',
                /* filter-nya berbentuk dropdown list */
                'filter' => Yii::$app->user->identity->id_satker == 1700 ? (Html::activeDropDownList($searchModel, 'satker', ArrayHelper::map(Satker::find()->asArray()->all(), 'nama_satker', 'nama_satker'), ['class' => 'form-control input', 'prompt' => 'Pilih Wilayah'])) : (FALSE),
            ],
            /* Menampilkan atribut perekam menurut nama pengguna dari tabel pengguna */
            [
                'attribute' => 'reporter',
                'value' => 'reporter.nama',
            ],
            [
                'attribute' => 'sumber',
                /* Mengambil tampilan data menggunakan fungsi getMedia() dari model Fenomena.php */
                'value' => function ($model) {
                    return $model->getMedia();
                },
                /* Filter untuk data berbentuk dropdown */
                'filter' => Html::activeDropDownList($searchModel, 'sumber', ['0' => 'Media Cetak', '1' => 'Media Online', '2' => 'Narasumber'], ['class' => 'form-control input', 'prompt' => 'Pilih Sumber']),
            ],
            'fenomena:ntext',
                        
            /* Menampilkan action buttons di gridview paling kanan */
            [
                'class' => 'yii\grid\ActionColumn',
                'header' => 'Rincian', //memberi nama kolom

                /* Mengatur alignment teks */
                'contentOptions' => ['class' => 'text-center'],
                /* Mengatur visibility (user authorization) pada tombol update dan delete */
                'visibleButtons' => [
                    'update' => function ($model, $key, $index) {
                        return ($model->perekam == Yii::$app->user->identity->username) ? true : false;
                    },
                    'delete' => function ($model, $key, $index) {
                        return ($model->perekam == Yii::$app->user->identity->username) ? true : false;
                    }
                ],
            ],
        ],
    ]);
    ?>
</div>
