<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\CariFenomena */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="fenomena-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>

    <?= $form->field($model, 'id') ?>

    <?= $form->field($model, 'wilayah') ?>

    <?= $form->field($model, 'bulan') ?>

    <?= $form->field($model, 'tahun') ?>

    <?= $form->field($model, 'fenomena') ?>

    <?php // echo $form->field($model, 'sumber') ?>

    <?php // echo $form->field($model, 'sumberket') ?>

    <?php // echo $form->field($model, 'kat01') ?>

    <?php // echo $form->field($model, 'kat02') ?>

    <?php // echo $form->field($model, 'kat03') ?>

    <?php // echo $form->field($model, 'kat04') ?>

    <?php // echo $form->field($model, 'kat05') ?>

    <?php // echo $form->field($model, 'kat06') ?>

    <?php // echo $form->field($model, 'kat07') ?>

    <?php // echo $form->field($model, 'kat08') ?>

    <?php // echo $form->field($model, 'kat09') ?>

    <?php // echo $form->field($model, 'kat10') ?>

    <?php // echo $form->field($model, 'kat11') ?>

    <?php // echo $form->field($model, 'kat12') ?>

    <?php // echo $form->field($model, 'kat13') ?>

    <?php // echo $form->field($model, 'kat14') ?>

    <?php // echo $form->field($model, 'kat15') ?>

    <?php // echo $form->field($model, 'kat16') ?>

    <?php // echo $form->field($model, 'kat17') ?>

    <?php // echo $form->field($model, 'komp01') ?>

    <?php // echo $form->field($model, 'komp02') ?>

    <?php // echo $form->field($model, 'komp03') ?>

    <?php // echo $form->field($model, 'komp04') ?>

    <?php // echo $form->field($model, 'komp05') ?>

    <?php // echo $form->field($model, 'komp06') ?>

    <?php // echo $form->field($model, 'komp07') ?>

    <?php // echo $form->field($model, 'tgl_rekam') ?>

    <?php // echo $form->field($model, 'perekam') ?>

    <?php // echo $form->field($model, 'deleted') ?>

    <div class="form-group">
        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton('Reset', ['class' => 'btn btn-default']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
