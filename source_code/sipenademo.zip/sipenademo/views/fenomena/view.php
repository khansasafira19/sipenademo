<?php
/*Men-daftar modul yang digunakan*/
use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\models\Fenomena */

/*Menambahkan "Fenomena ke-" pada title berdasarkan id dari data yang ditampilkan.*/
$this->title = 'Fenomena ke-' . $model->id;
/*Mengubah nama tengah breadcrumbs menjadi "Daftar Fenomena" (halaman index)*/
$this->params['breadcrumbs'][] = ['label' => 'Daftar Fenomena', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;

?>
<div class="fenomena-view">
	<!--Menampilkan title (id data fenomena)-->
    <h1><?= Html::encode($this->title) ?></h1>
	
	<!--Menampilkan buttons Update dan Delete, hanya jika pengguna yang sedang login yang menginput data yang sedang diaksesnya.-->
	<?php if (Yii::$app->user->identity->username == $namapelapor)://username yang login sama dengan data perekam (variabel $namapelapor dari FenomenaController) pada item ini    ?>
    <p>
        <?= Html::a('Ubah', ['update', 'id' => $model->id], ['class' => 'btn btn-success']) ?>
        <?=
        Html::a('Hapus', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Anda yakin ingin menghapus fenomena ini?',
                'method' => 'post',
            ],            
        ])
        ?>
    </p>
    <?php endif; ?>
	
	<!--Menampilkan data dengan detailview-->
    <?=
    DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'tahun',
            [
				/*atribut bulan, relation dengan tabel bulan (variabel month)*/
                'attribute' => 'month',
                'value' => $model->month->nama_bulan,
            ],
            [
				/*atribut wilayah, relation dengan tabel satker (variabel satker)*/
                'attribute' => 'satker',
                'value' => $model->satker->nama_satker,
            ],
            [
                /*atribut sumber, ditampilkan dengan fungsi getMedia() dari model Fenomena.php*/
				'attribute' => 'sumber',
                'value' => $model->media,
            ],
            'sumberket',
            'fenomena:ntext',
			/*atribut kat01, kat02, dst diterjemahkan dengan fungsi penerjemahan data boolean*/
            [
                'attribute' => 'kat01',
				/*jika kat01 = 0, data yang ditampilkan "Tidak". Jika kat01 = 1, data yang ditampilkan "Ya." */
                'value' => (($model->kat01 == '') ? 'Tidak' : 'Ya'),
            ],
            [
                'attribute' => 'kat02',
                'value' => (($model->kat02 == '') ? 'Tidak' : 'Ya'),
            ],
            [
                'attribute' => 'kat03',
                'value' => (($model->kat03 == '') ? 'Tidak' : 'Ya'),
            ],
            [
                'attribute' => 'kat04',
                'value' => (($model->kat04 == '') ? 'Tidak' : 'Ya'),
            ],
            [
                'attribute' => 'kat05',
                'value' => (($model->kat05 == '') ? 'Tidak' : 'Ya'),
            ],
            [
                'attribute' => 'kat06',
                'value' => (($model->kat06 == '') ? 'Tidak' : 'Ya'),
            ],
            [
                'attribute' => 'kat07',
                'value' => (($model->kat07 == '') ? 'Tidak' : 'Ya'),
            ],
            [
                'attribute' => 'kat08',
                'value' => (($model->kat08 == '') ? 'Tidak' : 'Ya'),
            ],
            [
                'attribute' => 'kat09',
                'value' => (($model->kat09 == '') ? 'Tidak' : 'Ya'),
            ],
            [
                'attribute' => 'kat10',
                'value' => (($model->kat10 == '') ? 'Tidak' : 'Ya'),
            ],
            [
                'attribute' => 'kat11',
                'value' => (($model->kat11 == '') ? 'Tidak' : 'Ya'),
            ],
            [
                'attribute' => 'kat12',
                'value' => (($model->kat12 == '') ? 'Tidak' : 'Ya'),
            ],
            [
                'attribute' => 'kat13',
                'value' => (($model->kat13 == '') ? 'Tidak' : 'Ya'),
            ],
            [
                'attribute' => 'kat14',
                'value' => (($model->kat14 == '') ? 'Tidak' : 'Ya'),
            ],
            [
                'attribute' => 'kat15',
                'value' => (($model->kat15 == '') ? 'Tidak' : 'Ya'),
            ],
            [
                'attribute' => 'kat16',
                'value' => (($model->kat16 == '') ? 'Tidak' : 'Ya'),
            ],
            [
                'attribute' => 'kat17',
                'value' => (($model->kat17 == '') ? 'Tidak' : 'Ya'),
            ],
                        [
                'attribute' => 'komp01',
                'value' => (($model->komp01 == '') ? 'Tidak' : 'Ya'),
            ],
            [
                'attribute' => 'komp02',
                'value' => (($model->komp02 == '') ? 'Tidak' : 'Ya'),
            ],
            [
                'attribute' => 'komp03',
                'value' => (($model->komp03 == '') ? 'Tidak' : 'Ya'),
            ],
            [
                'attribute' => 'komp04',
                'value' => (($model->komp04 == '') ? 'Tidak' : 'Ya'),
            ],
            [
                'attribute' => 'komp05',
                'value' => (($model->komp05 == '') ? 'Tidak' : 'Ya'),
            ],
            [
                'attribute' => 'komp06',
                'value' => (($model->komp06 == '') ? 'Tidak' : 'Ya'),
            ],
            [
                'attribute' => 'komp07',
                'value' => (($model->komp07 == '') ? 'Tidak' : 'Ya'),
            ],
            [
                /*tampilan tgl_rekam menjadi d MMMM y pada H:mm a
				contohnya: 4 July 2018 pada 12:04 pm*/
				'attribute' => 'tgl_rekam',
                'value' => \Yii::$app->formatter->asDatetime(strtotime($model->tgl_rekam), "d MMMM y 'pada' H:mm a"),
            ],
            [
                /*atribut perekam, relation dengan tabel pengguna (variabel reporter)*/
				'attribute' => 'reporter',
                'value' => $model->reporter->nama,
            ],
            //'deleted',
        ],
    ])
    ?>

</div>
