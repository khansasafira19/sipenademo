<?php
/* @var $this \yii\web\View */
/* @var $content string */

use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use app\assets\AppAsset;

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
    <head>
        <meta charset="<?= Yii::$app->charset ?>">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?= Html::csrfMetaTags() ?>
        <title><?= Html::encode(Yii::$app->name) ?></title>
        <?php $this->head() ?>
        <link rel="shortcut icon" href="<?php echo Yii::$app->request->baseUrl; ?>\images\favicon.png" type="image/x-icon" />
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
    </head>
    <body>
        <?php $this->beginBody() ?>
        <style>
            ul.breadcrumb > li > a {
                color: #008000!important;
            }
            .breadcrumb {                
                background-color: #DFF0D8!important;
            }
        </style>
        <div class="wrap">
            <?php
            NavBar::begin([
                'brandLabel' => 'SIPENA',
                'brandUrl' => Yii::$app->homeUrl,
                'options' => [
                    'class' => 'navbar-inverse navbar-fixed-top',
                ],
            ]);
            echo Nav::widget([
                'options' => ['class' => 'navbar-nav navbar-right'],
                'items' => [
                    ['label' => 'Beranda', 'url' => ['/site/index']],
                    ['label' => 'Rekam Fenomena', 'url' => ['/fenomena/create']],
                    [
                        'label' => 'Laporan Fenomena',
                        'items' => [
                            ['label' => 'Daftar Fenomena', 'url' => ['/fenomena/index']],
                            ['label' => 'Jumlah Entri', 'url' => ['/fenomena/jumlahentri', 'a' => date("Y"), 'b' => date("n")]],
                            ['label' => 'Jumlah Fenomena', 'url' => ['/fenomena/jumlahfen', 'a' => date("Y"), 'b' => date("n")]],
                        ],
                    ],
                    Yii::$app->user->isGuest ? (
                            ['label' => 'Login', 'url' => ['/site/login']]
                            ) : (
                            '<li>'
                            . Html::beginForm(['/site/logout'], 'post')
                            . Html::submitButton(
                                    'Logout (' . Yii::$app->user->identity->nama . ')', ['class' => 'btn btn-link logout'])
                            . Html::endForm()
                            . '</li>'
                            )
                ],
            ]);

            NavBar::end();
            ?>

            <div class="container">
                <?=
                Breadcrumbs::widget([
                    'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
                ])
                ?>
                <?= $content ?>
            </div>
        </div>

        <footer class="footer">
            <div class="container">
                <p class="pull-left">&copy; BPS Provinsi Bengkulu <?= date('Y') ?></p>

                <p class="pull-right">Developer: nofriani@bps.go.id</p>
            </div>
        </footer>

        <?php $this->endBody() ?>
    </body>
</html>
<?php $this->endPage() ?>
