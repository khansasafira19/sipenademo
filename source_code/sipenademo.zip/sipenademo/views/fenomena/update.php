<?php
/*Menggunakan modul Yii*/
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Fenomena */

/*Membuat judul halaman dengan id data terpilih*/
$this->title = 'Ubah Fenomena: ' . $model->id;
/*Membuat breadcrumbs*/
$this->params['breadcrumbs'][] = ['label' => 'Daftar Fenomena', 'url' => ['index']];
/*Menambahkan id data pada parameter breadcrumbs*/
$this->params['breadcrumbs'][] = ['label' => $model->id, 'url' => ['view', 'id' => $model->id]];
/*Menambahkan update pada parameter breadcrumbs*/
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="fenomena-update">
	<!--Menampilkan judul-->
    <h1><?= Html::encode($this->title) ?></h1>
	<!--Me-render view dari file sipena\views\fenomena\_form.php yang mengandung form isian data fenomena-->
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
