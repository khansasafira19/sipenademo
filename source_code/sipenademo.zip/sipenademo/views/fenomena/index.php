<?php
/* Men-daftar modul Yii dalam file ini */

use yii\helpers\Html;
use yii\grid\GridView;
/* Menggunakan model-model yang digunakan dalam relation */
use app\models\Bulan;
use app\models\Satker;
use app\models\Penggunasipantas;
/* Menggunakan modul ArrayHelper */
use yii\helpers\ArrayHelper;

/* Menggunakan modul export menu dari kartik */
use kartik\export\ExportMenu;

/* @var $this yii\web\View */
/* @var $searchModel app\models\CariFenomena */
/* @var $dataProvider yii\data\ActiveDataProvider */

/* Memberi judul pada halaman ini */
$this->title = 'Daftar Fenomena';
/* Menampilkan breadcrumbs (navigasi) dengan title */
$this->params['breadcrumbs'][] = $this->title;
?>
<style>
    .table-striped > tbody > tr:nth-of-type(odd) {
        background-color: #DFF0D8!important;
    }
    .table-striped > thead > tr > th{
        color: #008000!important;
    }
    .table-striped > thead > tr > th > a{
        color: #008000!important;
    }
    .table-striped > tbody > tr > td > a {
        color: #008000!important;
    }
</style>
<div class="fenomena-index">
    <!--Menampilkan title halaman-->
    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]);  ?>

    <p>
        <!--Menampilkan tombol "Rekam Fenomena" di bawah halaman title-->
        <?= Html::a('Rekam Fenomena', ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <!--Menampilkan menu export data biasa-->
    <?=
    ExportMenu::widget([
        /* Variabel $dataprovider dari controller */
        'dataProvider' => $dataProvider,
        /* Kolom yang dapat dipilih untuk diekspor */
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
            'tahun',
            [
                'attribute' => 'month',
                'value' => 'month.nama_bulan',
            ],
            [
                'attribute' => 'satker',
                'value' => 'satker.nama_satker',
            ],
            [
                'attribute' => 'sumber',
            ],
            'sumberket',
            'fenomena:ntext',
            'kat01', 'kat02', 'kat03', 'kat04', 'kat05', 'kat06', 'kat07', 'kat08', 'kat09',
            'kat10', 'kat11', 'kat12', 'kat13', 'kat14', 'kat15', 'kat16', 'kat17', 'tgl_rekam',
            'komp01', 'komp02', 'komp03', 'komp04', 'komp05', 'komp06', 'komp07',
            [
                'attribute' => 'reporter',
                'value' => 'reporter.nama',
            ],
        ],
        /* Style dari dropdown menu ekspor */
        'dropdownOptions' =>
        [
            /* Nama fitur */
            'label' => 'Export',
            /* Warna fitur: orange (warning) */
            'class' => 'btn btn-default btn-warning dropdown-toggle'
        ],
        /* Style dari menu memilih kolom untuk diekspor */
        'columnSelectorOptions' =>
        [
            /* Nama fitur */
            'label' => 'Pilih Kolom Export',
            /* Warna fitur: orange (warning) */
            'class' => 'btn btn-default btn-warning dropdown-toggle',
            /* Daftar kolom pada fitur dapat di-scroll down */
            'scrollable' => true,
        ],
        /* Style lain yang diperlukan */
        'columnSelectorMenuOptions' =>
        [
            'style' => 'overflow-y: scroll, height: auto; 
                       max-height: 200px;  overflow-x: hidden;',
        ],
        /* Pilihan bentuk file untuk diekspor */
        'exportConfig' =>
        [
            ExportMenu::FORMAT_HTML => false,
            ExportMenu::FORMAT_EXCEL => false,
            ExportMenu::FORMAT_PDF => false,
            ExportMenu::FORMAT_EXCEL_X =>
            [
                'label' => 'EXCEL',
            ],
            ExportMenu::FORMAT_TEXT =>
            [
                'label' => 'TXT',
            ]
        ],
    ]);
    ?>
    <!--Menampilkan menu export raw data khusus untuk pengguna dari BPS Provinsi-->
    <!--Memeriksa jika pengguna adalah dari BPS Provinsi (id_satker = 1700)-->
    <?php if (Yii::$app->user->identity->id_satker == 1700): ?>
        <div class="pull-right">
            <?=
            ExportMenu::widget([
                /* Variabel $$rawdata dari controller */
                'dataProvider' => $rawdata,
                /* Kolom yang dapat dipilih untuk diekspor */
                'columns' => [
                    ['class' => 'yii\grid\SerialColumn'],
                    'tahun',
                    [
                        'attribute' => 'month',
                        'value' => 'month.nama_bulan',
                    ],
                    [
                        'attribute' => 'satker',
                        'value' => 'satker.nama_satker',
                    ],
                    [
                        'attribute' => 'sumber',
                    ],
                    'sumberket',
                    'fenomena:ntext',
                    'kat01', 'kat02', 'kat03', 'kat04', 'kat05',
                    'kat06', 'kat07', 'kat08', 'kat09', 'kat10',
                    'kat11', 'kat12', 'kat13', 'kat14', 'kat15',
                    'kat16', 'kat17', 'komp01', 'komp02', 'komp03',
                    'komp04', 'komp05', 'komp06', 'komp07', 'tgl_rekam',
                    [
                        'attribute' => 'reporter',
                        'value' => 'reporter.nama',
                    ],
                    'deleted',
                ],
                /* Style dari dropdown menu ekspor */
                'dropdownOptions' =>
                [
                    /* Nama fitur */
                    'label' => 'Export Raw Data',
                    /* Warna fitur: red (danger) */
                    'class' => 'btn btn-default btn-danger dropdown-toggle'
                ],
                /* Style dari menu memilih kolom untuk diekspor */
                'columnSelectorOptions' =>
                [
                    /* Nama fitur */
                    'label' => 'Pilih Raw Data',
                    /* Warna fitur: red (danger) */
                    'class' => 'btn btn-default btn-danger dropdown-toggle',
                    /* Daftar kolom pada fitur dapat di-scroll down */
                    'scrollable' => true,
                ],
                /* Style lain yang diperlukan */
                'columnSelectorMenuOptions' =>
                [
                    'style' => 'overflow-y: scroll, height: auto; 
                       max-height: 200px;  overflow-x: hidden;',
                ],
                /* Pilihan bentuk file untuk diekspor */
                'exportConfig' =>
                [
                    ExportMenu::FORMAT_HTML => false,
                    ExportMenu::FORMAT_EXCEL => false,
                    ExportMenu::FORMAT_PDF => false,
                    ExportMenu::FORMAT_EXCEL_X =>
                    [
                        'label' => 'EXCEL',
                    ],
                    ExportMenu::FORMAT_TEXT =>
                    [
                        'label' => 'TXT',
                    ]
                ],
            ]);
            ?>
        </div>

        <!--Memeriksa jika pengguna bukan dari BPS Provinsi (id_satker != 1700)-->
    <?php else: ?>
        <!--Jika pengguna tidak berasal dari BPS Provinsi, menu ekspor raw data tidak ditampilkan-->
        <?php ?>  
    <?php endif; ?>

    <!--Menampilkan gridview-->
    <?=
    GridView::widget([
        /* Mengambil dataProvider dan searchModel yang disediakan oleh controller pada fungsi render */
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        /* Memilih kolom/atribut tabel untuk ditampilkan */
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
            //'id',
            'tahun',
            /* Menampilkan atribut bulan menurut nama bulan dari tabel bulan */
            [
                'attribute' => 'month', //nama atribut (relation-nya)
                'value' => 'month.nama_bulan', //nilainya diambil dari fungsi relation
                /* filter-nya berbentuk dropdown list */
                'filter' => Html::activeDropDownList($searchModel, 'month', ArrayHelper::map(Bulan::find()->asArray()->all(), 'nama_bulan', 'nama_bulan'), ['class' => 'form-control input', 'prompt' => 'Pilih Bulan']),
            ],
            /* Menampilkan atribut wilayah menurut nama wilayah dari tabel satker */
            [
                'attribute' => 'satker', //nama relation-nya
                'value' => 'satker.nama_satker',
                /* filter-nya berbentuk dropdown list */
                'filter' => Yii::$app->user->identity->id_satker == 1700 ? (Html::activeDropDownList($searchModel, 'satker', ArrayHelper::map(Satker::find()->asArray()->all(), 'nama_satker', 'nama_satker'), ['class' => 'form-control input', 'prompt' => 'Pilih Wilayah'])) : (FALSE),
            ],
            /* Menampilkan atribut perekam menurut nama pengguna dari tabel pengguna */
            [
                'attribute' => 'reporter',
                'value' => 'reporter.nama',
            ],
            [
                'attribute' => 'sumber',
                /* Mengambil tampilan data menggunakan fungsi getMedia() dari model Fenomena.php */
                'value' => function ($model) {
                    return $model->getMedia();
                },
                /* Filter untuk data berbentuk dropdown */
                'filter' => Html::activeDropDownList($searchModel, 'sumber', ['0' => 'Media Cetak', '1' => 'Media Online', '2' => 'Narasumber'], ['class' => 'form-control input', 'prompt' => 'Pilih Sumber']),
            ],
            'fenomena:ntext',
            /* Menampilkan action buttons di gridview paling kanan */
            [
                'class' => 'yii\grid\ActionColumn',
                'header' => 'Rincian', //memberi nama kolom

                /* Mengatur alignment teks */
                'contentOptions' => ['class' => 'text-center'],
                /* Mengatur visibility (user authorization) pada tombol update dan delete */
                'visibleButtons' => [
                    'update' => function ($model, $key, $index) {
                        return ($model->perekam == Yii::$app->user->identity->username) ? true : false;
                    },
                    'delete' => function ($model, $key, $index) {
                        return ($model->perekam == Yii::$app->user->identity->username) ? true : false;
                    }
                ],
            ],
        ],
    ]);
    ?>

</div>
